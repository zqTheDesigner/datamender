def hw():
    print('Hello World')